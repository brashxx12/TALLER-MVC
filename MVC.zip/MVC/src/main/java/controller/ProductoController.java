/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.Producto;
import view.ProductoView;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Optional;

public class ProductoController {
    private ArrayList<Producto> productos;
    private ProductoView view;

    public ProductoController() {
        productos = new ArrayList<>();
        view = new ProductoView();
    }

    public void registrarProducto(Producto producto) {
        productos.add(producto);
        view.mostrarMensaje("Producto registrado correctamente.");
    }

    public void listarProductos() {
        if (productos.isEmpty()) {
            view.mostrarMensaje("No hay productos registrados.");
            return;
        }
        for (Producto p : productos) {
            view.mostrarProducto(p);
        }
    }

    public Producto buscarProducto(int id) {
        for (Producto p : productos) {
            if (p.getId() == id) return p;
        }
        return null;
    }

    public void listarProductosPrecioMayor100() {
        productos.stream()
                 .filter(p -> p.getPrecio() > 100)
                 .forEach(p -> view.mostrarProducto(p));
    }

    public void buscarPorNombre(String nombre) {
        productos.stream()
                 .filter(p -> p.getNombre().equalsIgnoreCase(nombre))
                 .forEach(p -> view.mostrarProducto(p));
    }

    public void listarStockBajo() {
        productos.stream()
                 .filter(p -> p.getStock() < 10)
                 .forEach(p -> view.mostrarProducto(p));
    }

    // Reto 1: Eliminar producto por ID
    public boolean eliminarProducto(int id) {
        boolean eliminado = productos.removeIf(p -> p.getId() == id);
        if (eliminado) {
            view.mostrarMensaje("Producto eliminado correctamente.");
        } else {
            view.mostrarMensaje("Producto no encontrado.");
        }
        return eliminado;
    }

    // Reto 2: Producto más caro usando max()
    public void mostrarProductoMasCaro() {
        Optional<Producto> masCaro = productos.stream()
                .max(Comparator.comparingDouble(Producto::getPrecio));

        if (masCaro.isPresent()) {
            view.mostrarMensaje("Producto más caro:");
            view.mostrarProducto(masCaro.get());
        } else {
            view.mostrarMensaje("No hay productos en el inventario.");
        }
    }

    // Reto 3: Contar productos con stock < 10 usando count()
    public void contarStockBajo() {
        long cantidad = productos.stream()
                .filter(p -> p.getStock() < 10)
                .count();

        view.mostrarMensaje("Total de productos con stock menor a 10: " + cantidad);
    }

    // Reto 4: Actualizar producto
    public void actualizarProducto(int id, double nuevoPrecio, int nuevoStock) {
        Producto p = buscarProducto(id);
        if (p != null) {
            p.setPrecio(nuevoPrecio);
            p.setStock(nuevoStock);
            view.mostrarMensaje("Producto actualizado correctamente.");
        } else {
            view.mostrarMensaje("Producto no encontrado para actualizar.");
        }
    }
}