/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import controller.ProductoController;
import model.Producto;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ProductoController controller = new ProductoController();
        Scanner scanner = new Scanner(System.in);

        // Precargar productos iniciales
        controller.registrarProducto(new Producto(1, "Laptop", 1200.00, 5));
        controller.registrarProducto(new Producto(2, "Mouse", 15.50, 20));
        controller.registrarProducto(new Producto(3, "Teclado", 45.00, 8));
        controller.registrarProducto(new Producto(4, "Monitor", 250.00, 12));
        controller.registrarProducto(new Producto(5, "Impresora", 180.00, 3));

        int opcion = 0;

        do {
            System.out.println("\n===== SISTEMA DE INVENTARIO =====");
            System.out.println("1. Registrar producto");
            System.out.println("2. Listar productos");
            System.out.println("3. Buscar por ID");
            System.out.println("4. Buscar por nombre");
            System.out.println("5. Precio mayor a $100");
            System.out.println("6. Stock bajo (< 10)");
            System.out.println("7. Eliminar producto (Reto 1)");
            System.out.println("8. Producto más caro (Reto 2)");
            System.out.println("9. Contar stock bajo (Reto 3)");
            System.out.println("10. Actualizar producto (Reto 4)");
            System.out.println("11. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                opcion = 0;
            }

            switch (opcion) {
                case 1:
                    System.out.print("ID: ");
                    int id = Integer.parseInt(scanner.nextLine());
                    System.out.print("Nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Precio: ");
                    double precio = Double.parseDouble(scanner.nextLine());
                    System.out.print("Stock: ");
                    int stock = Integer.parseInt(scanner.nextLine());
                    controller.registrarProducto(new Producto(id, nombre, precio, stock));
                    break;
                case 2:
                    controller.listarProductos();
                    break;
                case 3:
                    System.out.print("Ingrese ID a buscar: ");
                    int idBuscar = Integer.parseInt(scanner.nextLine());
                    Producto pEncontrado = controller.buscarProducto(idBuscar);
                    if (pEncontrado != null) {
                        System.out.println(pEncontrado);
                    } else {
                        System.out.println("Producto no encontrado.");
                    }
                    break;
                case 4:
                    System.out.print("Ingrese nombre a buscar: ");
                    String nombreBuscar = scanner.nextLine();
                    controller.buscarPorNombre(nombreBuscar);
                    break;
                case 5:
                    controller.listarProductosPrecioMayor100();
                    break;
                case 6:
                    controller.listarStockBajo();
                    break;
                case 7:
                    System.out.print("Ingrese ID a eliminar: ");
                    int idEliminar = Integer.parseInt(scanner.nextLine());
                    controller.eliminarProducto(idEliminar);
                    break;
                case 8:
                    controller.mostrarProductoMasCaro();
                    break;
                case 9:
                    controller.contarStockBajo();
                    break;
                case 10:
                    System.out.print("Ingrese ID a actualizar: ");
                    int idAct = Integer.parseInt(scanner.nextLine());
                    System.out.print("Nuevo Precio: ");
                    double nPrecio = Double.parseDouble(scanner.nextLine());
                    System.out.print("Nuevo Stock: ");
                    int nStock = Integer.parseInt(scanner.nextLine());
                    controller.actualizarProducto(idAct, nPrecio, nStock);
                    break;
                case 11:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 11);

        scanner.close();
    }
}