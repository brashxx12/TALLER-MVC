/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import model.Producto;

public class ProductoView {
    public void mostrarProducto(Producto producto) {
        System.out.println(producto);
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
